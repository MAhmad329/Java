package LabMidterm;


public class IslamabadBranch extends Enchanted {

    public IslamabadBranch(){
        super();
        super.branch = "Islamabad";
    }

    public void placeOrder(){
        super.placeOrder();
    }
    
}
